a = str.maketrans("ODIZSB", "001258")

S = input()
print(S.translate(a))