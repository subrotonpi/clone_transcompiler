S = input()
T = S.replace('O','0').replace('D','0').replace('I','1').replace('Z','2').replace('S','5').replace('B','8')
print(T)