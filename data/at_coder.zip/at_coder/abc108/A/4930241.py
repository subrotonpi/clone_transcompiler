K=int(input())
print((K//2)*((K+1)//2))