n = int(input())
e = o = n // 2
if ( n % 2 != 0):
  o += 1
print(e * o)