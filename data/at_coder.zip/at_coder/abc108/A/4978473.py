n = int(input())
a = (n + 1) // 2
b = n // 2
print(a * b)