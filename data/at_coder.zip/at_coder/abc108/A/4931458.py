n = int(input())
a = 0
for i in range(2, n+1, 2): a += n-i+1
print(a)