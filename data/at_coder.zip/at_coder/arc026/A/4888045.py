N,A,B=map(int,input().split())
if N>5:
    print((N-5)*A+5*B)
else:
    print(B*N)